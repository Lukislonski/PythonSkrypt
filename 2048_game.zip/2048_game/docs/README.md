# Gra 2048 w Konsoli

Jest to konsolowa implementacja popularnej gry logicznej 2048, napisana w Pythonie. Projekt oferuje konfigurowalne ustawienia, zapisywanie stanu gry, śledzenie najlepszych wyników oraz podstawowe narzędzia analityczne.

## Spis treści

1.  [Opis Projektu]
2.  [Cechy Gry]
3.  [Wymagania]
4.  [Instalacja]
5.  [Uruchamianie Gry]
6.  [Jak Grać?]
7.  [Struktura Projektu]
8.  [Resetowanie Danych]
9.  [Możliwe Ulepszenia]

## 1. Opis Projektu

Konsolowa wersja gry 2048, która pozwala na rozgrywkę bezpośrednio w terminalu. Celem gry jest przesuwanie ponumerowanych kafelków na siatce, aby połączyć je w kafelek o wartości 2048 (lub innej zdefiniowanej wartości docelowej). Projekt został zaprojektowany z myślą o modularności i łatwości rozbudowy.

## 2. Cechy Gry

* **Standardowa rozgrywka 2048**: Klasyczna mechanika gry.
* **Konfigurowalna plansza**: Możliwość zmiany rozmiaru planszy (np. 3x3, 4x4).
* **Konfigurowalna wartość docelowa**: Ustaw własny cel gry (np. 512, 1024, 2048).
* **Zapisywanie i wczytywanie gry**:
    * Automatyczny zapis stanu gry po każdym ruchu.
    * Ręczny zapis i wczytywanie gry w dowolnym momencie.
* **Cofanie ruchu**: Możliwość cofnięcia ostatniego ruchu.
* **System najlepszych wyników (Highscores)**:
    * Przechowywanie wyników w bazie danych SQLite.
    * Wyświetlanie top 5 wyników.
    * Resetowanie rankingu.
    * Weryfikacja integralności wyników za pomocą sum kontrolnych.
* **Podstawowe statystyki i raporty**: Generowanie wizualnych raportów (np. histogram wyników) w formacie PNG.
* **Kolorowy interfejs użytkownika (UI)**: Wykorzystanie biblioteki `colorama` dla lepszych wrażeń wizualnych.
* **Obsługa argumentów wiersza poleceń**: Szybka konfiguracja rozmiaru planszy, wartości docelowej i poziomu logowania przy starcie.
* **System trybów gry**: Architektura umożliwiająca łatwe dodawanie nowych trybów rozgrywki.

## 3. Wymagania

* Python 3.8+
* `pip`

## 4. Instalacja

    **Zainstaluj zależności:**
    ```bash
    pip install -r requirements.txt
    ```
   

## 5. Uruchamianie Gry

Uruchom grę za pomocą pliku `main.py`:
