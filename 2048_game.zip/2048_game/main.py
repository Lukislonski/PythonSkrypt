# main.py

import argparse
import logging
import os
import sys
import time

from src.core.board import Board
from src.core.game import Game
from src.core.constants import (
    DEFAULT_BOARD_SIZE, DEFAULT_TARGET_VALUE, UI_COLORS, SAVE_FILE, AUTOSAVE_FILE,
    GAME_MODES_MAP, AVAILABLE_BOARD_SIZES, AVAILABLE_TARGET_VALUES,
    MIN_BOARD_SIZE, MAX_BOARD_SIZE
)
from src.data.config import ConfigManager
from src.data.highscore import HighscoreManager
from src.data.save_load import SaveLoadManager
from src.modes.game_mode import GameMode, StandardGameMode
from src.modes.mode_manager import ModeManager
from src.stats.analytics import AnalyticsManager
from src.stats.game_stats import GameStats
from src.ui.console_renderer import ConsoleRenderer
from src.ui.input_handler import InputHandler
from src.ui.menu import Menu
from src.utils.helpers import (
    exit_game, clear_console, set_global_renderer, display_welcome_screen,
    get_user_input, validate_board_size, display_game_info
)
from src.utils.logger import game_logger

class MainApp:
    def __init__(self, initial_config=None, force_new_game=False):
        """
        Konstruktor klasy MainApp.
        Inicjalizuje wszystkie komponenty aplikacji, takie jak menedżery konfiguracji,
        wyników, zapisów, elementy interfejsu użytkownika oraz logikę gry.
        """
        self.logger = game_logger
        self.logger.info("Aplikacja 2048 - Inicjalizacja...")

        self.config_manager = ConfigManager()
        if initial_config:
            self.config_manager.update_config(initial_config)

        self.game_stats = GameStats()
        self.highscore_manager = HighscoreManager()
        
        self.manual_save_load_manager = SaveLoadManager(SAVE_FILE)
        self.autosave_load_manager = SaveLoadManager(AUTOSAVE_FILE)

        # Inicjalizacja komponentów UI
        self.renderer = ConsoleRenderer(self.config_manager)
        set_global_renderer(self.renderer)
        self.logger.info("ConsoleRenderer zainicjalizowany.")

        self.input_handler = InputHandler()
        self.game = Game(
            config_manager=self.config_manager,
            game_stats=self.game_stats,
            highscore_manager=self.highscore_manager,
            manual_save_load_manager=self.manual_save_load_manager,
            autosave_load_manager=self.autosave_load_manager,
            logger=self.logger,
            input_handler=self.input_handler
        )
        self.board = self.game.board

        self.menu = Menu(
            renderer=self.renderer,
            input_handler=self.input_handler,
            config_manager=self.config_manager,
            highscore_manager=self.highscore_manager,
            game=self.game
        )

        self.mode_manager = ModeManager(
            game=self.game,
            renderer=self.renderer,
            config_manager=self.config_manager,
            highscore_manager=self.highscore_manager
        )

        self.analytics_manager = AnalyticsManager(
            self.highscore_manager,
            self.config_manager,
            self.game.logger
        )

        if force_new_game:
            self.logger.info("Wymuszono nową grę za pomocą argumentu wiersza poleceń (--new).")
            self.game.start_new_game(self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE))
        elif not self.game.load_game():
            self.game.start_new_game()
            self.logger.info("Brak zapisanego stanu gry. Rozpoczęto nową grę.")


    def run(self):
        """
        Główna pętla gry.
        Odpowiada za renderowanie planszy, wyświetlanie informacji o grze,
        sprawdzanie warunków wygranej/przegranej oraz obsługę wejścia użytkownika.
        """
        display_welcome_screen(self.input_handler)

        while True:
            clear_console()
            self.renderer.render_board(self.game.board.get_board())
            
            top_highscore_entry = self.highscore_manager.get_top_highscores(1)
            current_top_highscore = top_highscore_entry[0]['score'] if top_highscore_entry else 0

            display_game_info(
                self.game.game_stats.get_score(),
                current_top_highscore,
                self.game.game_stats.get_moves()
            )

            if self.game.check_win():
                self.renderer.render_message(UI_COLORS['HIGHLIGHT'] + "Gratulacje! Wygrałeś!" + UI_COLORS['RESET'] + "\n")
                self.game.handle_win()
                if not self.menu.ask_to_continue():
                    break
                else:
                    self.game.start_new_game()
                    continue

            if self.game.check_game_over():
                self.renderer.render_message(UI_COLORS['ERROR'] + "Koniec gry! Brak ruchów." + UI_COLORS['RESET'] + "\n")
                self.game.handle_game_over()
                self.renderer.render_message("\nNaciśnij dowolny klawisz, aby wrócić do menu głównego...")
                self.input_handler.get_key()
                self.game.start_new_game()
                continue


            key = self.input_handler.get_key()
            self.handle_input(key)

    def handle_input(self, key):
        """
        Obsługuje wejście klawiaturowe użytkownika podczas gry.
        Wykonuje odpowiednie akcje, takie jak ruchy na planszy, cofanie, zapis/wczytanie gry,
        wejście do menu głównego lub wyjście z gry.
        """
        self.logger.debug(f"Klawisz odebrany w handle_input: '{key}' (typ: {type(key)})")

        if key == 'UP':
            self.game.move('up')
        elif key == 'DOWN':
            self.game.move('down')
        elif key == 'LEFT':
            self.game.move('left')
        elif key == 'RIGHT':
            self.game.move('right')
        elif key == 'U':
            self.game.undo_move()
            self.renderer.render_message(UI_COLORS['INFO'] + "Cofnięto ruch." + UI_COLORS['RESET'])
            time.sleep(1.5)
        elif key == 'S':
            self.game.save_game()
            self.renderer.render_message(UI_COLORS['INFO'] + "Gra została zapisana." + UI_COLORS['RESET'])
            time.sleep(1.5)
        elif key == 'L':
            if self.game.load_game():
                clear_console()
                self.renderer.render_board(self.game.board.get_board())
                
                top_highscore_entry = self.highscore_manager.get_top_highscores(1)
                current_top_highscore = top_highscore_entry[0]['score'] if top_highscore_entry else 0
                display_game_info(
                    self.game.game_stats.get_score(),
                    current_top_highscore,
                    self.game.game_stats.get_moves()
                )
                
                self.renderer.render_message(UI_COLORS['INFO'] + "Gra została wczytana." + UI_COLORS['RESET'])
            else:
                self.renderer.render_message(UI_COLORS['WARNING'] + "Brak zapisanej gry do wczytania." + UI_COLORS['RESET'])
            time.sleep(1.5)
        elif key == 'M':
            self.show_main_menu()
        elif key == 'Q':
            exit_game()
        else:
            self.renderer.render_message(UI_COLORS['WARNING'] + "Nierozpoznany klawisz. Spróbuj ponownie." + UI_COLORS['RESET'])
            time.sleep(1.5)

    def show_main_menu(self):
        """
        Wyświetla główne menu gry i obsługuje wybór użytkownika.
        Pozwala na rozpoczęcie nowej gry, wczytanie, przejście do opcji,
        wyświetlenie wyników, raportu statystyk, zmianę trybu gry lub wyjście.
        """
        choice = self.menu.display_main_menu()
        if choice == '1':
            self.logger.debug("Calling start_new_game from main menu (New game option).")
            self.game.start_new_game(self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE))
            self.renderer.render_message(UI_COLORS['INFO'] + "Rozpoczęto nową grę." + UI_COLORS['RESET'])
        elif choice == '2':
            if self.game.load_game():
                self.renderer.render_message(UI_COLORS['INFO'] + "Gra została wczytana." + UI_COLORS['RESET'])
            else:
                self.renderer.render_message(UI_COLORS['WARNING'] + "Brak zapisanej gry do wczytania." + UI_COLORS['RESET'])
        elif choice == '3':
            self.show_options_menu()
        elif choice == '4':
            self.menu.display_highscores()
        elif choice == '5':
            self.analytics_manager.generate_stats_report()
            self.renderer.render_message(UI_COLORS['INFO'] + "Raport statystyk wygenerowany w folderze 'reports'." + UI_COLORS['RESET'])
            self.input_handler.get_key()
        elif choice == '6':
            self.show_game_mode_menu()
        elif choice == '7':
            exit_game()

    def show_options_menu(self):
        """
        Wyświetla menu opcji gry i obsługuje wybór użytkownika.
        Pozwala na zmianę rozmiaru planszy, wartości docelowej lub powrót.
        """
        while True:
            choice = self.menu.display_options_menu()
            if choice == '1':
                self.logger.debug("Calling change_board_size from options menu.")
                self.change_board_size()
            elif choice == '2':
                self.change_target_value()
            elif choice == '3':
                pass 
            elif choice == '4':
                break

    def change_board_size(self):
        """
        Umożliwia użytkownikowi zmianę rozmiaru planszy.
        Pobiera nowy rozmiar, waliduje go i aktualizuje konfigurację gry,
        rozpoczynając nową grę z nowym rozmiarem.
        """
        current_size = self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE)
        prompt = f"{UI_COLORS['MENU_OPTION']}Aktualny rozmiar planszy: {current_size}. Dostępne: {AVAILABLE_BOARD_SIZES}. Podaj nowy rozmiar planszy ({MIN_BOARD_SIZE}-{MAX_BOARD_SIZE}): {UI_COLORS['RESET']}"
        new_size_str = get_user_input(prompt, validate_board_size)
        if new_size_str:
            new_size = int(new_size_str)
            self.config_manager.set_setting('board_size', new_size)
            self.logger.debug(f"Calling start_new_game from change_board_size (new size: {new_size}).")
            self.game.start_new_game(new_size)
            self.renderer.render_message(UI_COLORS['INFO'] + f"Rozmiar planszy zmieniony na {new_size}. Rozpoczęto nową grę." + UI_COLORS['RESET'])
        else:
            self.renderer.render_message(UI_COLORS['WARNING'] + "Zmiana rozmiaru planszy anulowana." + UI_COLORS['RESET'])

    def change_target_value(self):
        """
        Umożliwia użytkownikowi zmianę wartości docelowej do osiągnięcia.
        Pobiera nową wartość, waliduje ją i aktualizuje konfigurację gry.
        """
        current_target = self.config_manager.get_setting('target_value', DEFAULT_TARGET_VALUE)
        prompt = f"{UI_COLORS['MENU_OPTION']}Aktualna wartość docelowa: {current_target}. Dostępne: {AVAILABLE_TARGET_VALUES}. Podaj nową wartość docelową: {UI_COLORS['RESET']}"
        new_target_str = get_user_input(prompt, lambda x: x.isdigit() and int(x) in AVAILABLE_TARGET_VALUES)
        if new_target_str:
            new_target = int(new_target_str)
            self.config_manager.set_setting('target_value', new_target)
            self.renderer.render_message(UI_COLORS['INFO'] + f"Wartość docelowa zmieniona na {new_target}." + UI_COLORS['RESET'])
        else:
            self.renderer.render_message(UI_COLORS['WARNING'] + "Zmiana wartości docelowej anulowana." + UI_COLORS['RESET'])

    def show_game_mode_menu(self):
        """
        Wyświetla menu wyboru trybu gry.
        Pozwala użytkownikowi wybrać jeden z dostępnych trybów i ustawić go jako aktywny.
        """
        available_modes = self.mode_manager.get_available_modes()
        if not available_modes:
            self.renderer.render_message(UI_COLORS['WARNING'] + "Brak dostępnych trybów gry." + UI_COLORS['RESET'])
            self.input_handler.get_key()
            return

        self.renderer.clear_screen()
        self.renderer.render_header("WYBÓR TRYBU GRY")
        for i, mode_name in enumerate(available_modes):
            self.renderer.render_menu_option(f"{i + 1}. {mode_name}")
        self.renderer.render_menu_option(f"{len(available_modes) + 1}. Powrót do menu głównego")

        choice_str = get_user_input(
            f"{UI_COLORS['MENU_OPTION']}Wybierz tryb gry: {UI_COLORS['RESET']}",
            lambda x: x.isdigit() and 1 <= int(x) <= len(available_modes) + 1
        )

        if choice_str:
            choice = int(choice_str)
            if 1 <= choice <= len(available_modes):
                selected_mode_name = available_modes[choice - 1]
                selected_mode_instance = self.mode_manager.get_mode_instance(selected_mode_name)
                self.game.set_current_mode(selected_mode_instance)
                self.renderer.render_message(UI_COLORS['INFO'] + f"Ustawiono tryb gry: {selected_mode_name}." + UI_COLORS['RESET'])
                self.logger.debug(f"Calling start_new_game from show_game_mode_menu (mode: {selected_mode_name}).")
                self.game.start_new_game(self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE))
                self.input_handler.get_key()
            else:
                self.renderer.render_message(UI_COLORS['INFO'] + "Powrót do menu głównego." + UI_COLORS['RESET'])
                self.input_handler.get_key()
        else:
            self.renderer.render_message(UI_COLORS['WARNING'] + "Wybór trybu gry anulowany." + UI_COLORS['RESET'])
            self.input_handler.get_key()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Gra 2048 w konsoli.")
    parser.add_argument('--new', action='store_true', 
                        help='Wymuś rozpoczęcie nowej gry, ignorując autozapis.')
    parser.add_argument('--board_size', type=int,
                        help=f"Rozmiar planszy ({MIN_BOARD_SIZE}-{MAX_BOARD_SIZE}). Domyślnie: {DEFAULT_BOARD_SIZE}")
    parser.add_argument('--target_value', type=int,
                        help=f"Wartość do osiągnięcia ({', '.join(map(str, AVAILABLE_TARGET_VALUES))}). Domyślnie: {DEFAULT_TARGET_VALUE}")
    parser.add_argument('--log_level', type=str, default='INFO',
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        help="Poziom logowania (DEBUG, INFO, WARNING, ERROR, CRITICAL). Domyślnie: INFO")

    args = parser.parse_args()

    numeric_level = getattr(logging, args.log_level.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError(f'Nieprawidłowy poziom logowania: {args.log_level}')
    game_logger.setLevel(numeric_level)


    initial_config_from_cli = {}
    if args.board_size:
        if not (MIN_BOARD_SIZE <= args.board_size <= MAX_BOARD_SIZE):
            game_logger.error(f"Nieprawidłowy rozmiar planszy: {args.board_size}. Musi być między {MIN_BOARD_SIZE} a {MAX_BOARD_SIZE}.")
            sys.exit(1)
        initial_config_from_cli['board_size'] = args.board_size

    if args.target_value:
        if args.target_value not in AVAILABLE_TARGET_VALUES:
            game_logger.error(f"Nieprawidłowa wartość docelowa: {args.target_value}. Musi być jedną z: {', '.join(map(str, AVAILABLE_TARGET_VALUES))}.")
            sys.exit(1)
        initial_config_from_cli['target_value'] = args.target_value

    app = MainApp(initial_config=initial_config_from_cli, force_new_game=args.new)
    app.run()
