#src/modes/game_mode.py

from __future__ import annotations
from typing import Tuple

"""
Moduł definiujący abstrakcyjną klasę bazową dla trybów gry
oraz implementację podstawowego trybu standardowego.
"""

from abc import ABC, abstractmethod
from src.utils.logger import game_logger

class GameMode(ABC):
    """
    Abstrakcyjna klasa bazowa dla wszystkich trybów gry.
    Definiuje interfejs, jaki powinien implementować każdy tryb gry.
    """

    def __init__(self, game: 'Game'):
        """
        Inicjalizuje tryb gry.
        """
        self.game = game
        self.name = "Podstawowy Tryb Gry"
        self.description = "Standardowa rozgrywka 2048."
        self.logger = game_logger

    @abstractmethod
    def handle_move(self, direction: str) -> bool:
        """
        Obsługuje ruch gracza w zależności od trybu gry.
        """
        pass

    @abstractmethod
    def is_game_over(self) -> bool:
        """
        Sprawdza, czy gra w tym trybie dobiegła końca.
        """
        pass

    @abstractmethod
    def check_win_condition(self) -> bool:
        """
        Sprawdza warunek zwycięstwa dla danego trybu gry.
        """
        pass

    def get_name(self) -> str:
        """Zwraca nazwę trybu gry."""
        return self.name

    def get_description(self) -> str:
        """Zwraca opis trybu gry."""
        return self.description

class StandardGameMode(GameMode):
    """
    Standardowy tryb gry 2048.
    """

    def __init__(self, game: 'Game'):
        super().__init__(game)
        self.name = "Standardowy"
        self.description = "Klasyczna gra 2048. Cel: osiągnij 2048."

    def handle_move(self, direction: str) -> Tuple[bool, int]:
        """
        Obsługuje ruch gracza w standardowym trybie gry.
        """
        board_changed, points_gained = self.game.board.move_tiles(direction)
        
        if board_changed:
            self.game.add_random_tile()
            self.game.game_stats.increment_moves()
            self.game.game_stats.update_max_tile(self.game.board.get_max_tile())
            
            if points_gained > 0:
                self.game.game_stats.add_score(points_gained)
                self.logger.debug(f"Dodano {points_gained} punktów za ruch.")

            self.logger.info(f"Ruch: {direction}, Plansza zmieniona.")
        else:
            self.logger.debug(f"Ruch: {direction}, Plansza niezmieniona.")
        return board_changed, points_gained

    def is_game_over(self) -> bool:
        """
        Sprawdza, czy gra w standardowym trybie jest zakończona.
        """
        return not self.game.board.has_valid_moves()

    def check_win_condition(self) -> bool:
        """
        Sprawdza warunek zwycięstwa w standardowym trybie gry (osiągnięcie 2048).
        """
        return self.game.game_stats.get_max_tile() >= self.game.config_manager.get_setting('target_value')