#src/modes/mode_manager.py

"""
Moduł do zarządzania różnymi trybami gry dostępnymi w 2048.
Odpowiada za wykrywanie, rejestrowanie i wybór trybów.
"""

import os
import importlib.util
from src.modes.game_mode import GameMode, StandardGameMode
from src.utils.logger import game_logger
from src.core.constants import DEFAULT_BOARD_SIZE

class ModeManager:
    """
    Klasa zarządzająca dostępnymi trybami gry.
    """
    def __init__(self, game, renderer, config_manager, highscore_manager):
        self.game = game
        self.renderer = renderer
        self.config_manager = config_manager
        self.highscore_manager = highscore_manager
        self.logger = game_logger
        self._registered_modes = {}
        self._discover_modes()

    def _discover_modes(self):
        """
        Odkrywa i rejestruje dostępne tryby gry.
        Na razie rejestruje tylko tryb standardowy.
        """
        # Przykład rejestracji trybu standardowego
        self.register_mode(StandardGameMode(self.game))
        self.logger.info("Domyślne tryby gry zarejestrowane.")

    def register_mode(self, mode_instance: GameMode):
        """
        Rejestruje instancję trybu gry.
        """
        self._registered_modes[mode_instance.get_name()] = mode_instance
        self.logger.info(f"Tryb gry '{mode_instance.get_name()}' zarejestrowany.")

    def get_available_modes(self) -> list[str]:
        """
        Zwraca listę nazw dostępnych trybów gry.
        """
        return list(self._registered_modes.keys())

    def get_mode_instance(self, mode_name: str) -> GameMode:
        """
        Zwraca instancję trybu gry o podanej nazwie.
        """
        mode = self._registered_modes.get(mode_name)
        if not mode:
            self.logger.warning(f"Próba uzyskania niezarejestrowanego trybu gry: {mode_name}. Zwracam tryb standardowy.")
            return self._registered_modes.get("Standardowy")
        return mode