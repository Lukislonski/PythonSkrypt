#src/data/config.py

"""
Moduł odpowiedzialny za zarządzanie ustawieniami konfiguracji gry 2048.
Umożliwia wczytywanie, zapisywanie i dostęp do ustawień z pliku YAML.
"""

import yaml
import os
import logging
from src.core.constants import (
    DEFAULT_BOARD_SIZE, DEFAULT_TARGET_VALUE, INITIAL_TILES, PROBABILITY_4,
    MIN_BOARD_SIZE, MAX_BOARD_SIZE, AVAILABLE_TARGET_VALUES
)
from src.utils.logger import game_logger

class ConfigManager:
    """
    Klasa zarządzająca ustawieniami konfiguracji gry.
    Wczytuje i zapisuje ustawienia do pliku YAML.
    """
    _config_data = {}
    _config_file_path = 'config/settings.yaml'
    _initialized = False

    def __init__(self, config_file=None):
        if not ConfigManager._initialized:
            if config_file:
                ConfigManager._config_file_path = config_file
            self._ensure_config_dir_exists()
            self.load_config()
            ConfigManager._initialized = True
        self.logger = game_logger

    @classmethod
    def _ensure_config_dir_exists(cls):
        """
        Upewnia się, że katalog dla pliku konfiguracyjnego istnieje.
        """
        config_dir = os.path.dirname(cls._config_file_path)
        if config_dir and not os.path.exists(config_dir):
            os.makedirs(config_dir)
            game_logger.info(f"Utworzono katalog konfiguracyjny: {config_dir}")

    @classmethod
    def load_config(cls):
        """
        Wczytuje ustawienia konfiguracji z pliku YAML.
        Jeśli plik nie istnieje lub jest pusty, ładuje domyślne ustawienia.
        """
        if os.path.exists(cls._config_file_path) and os.path.getsize(cls._config_file_path) > 0:
            try:
                with open(cls._config_file_path, 'r', encoding='utf-8') as f:
                    cls._config_data = yaml.safe_load(f)
                game_logger.info(f"Konfiguracja wczytana z {cls._config_file_path}")
            except yaml.YAMLError as e:
                game_logger.error(f"Błąd podczas wczytywania pliku konfiguracyjnego: {e}. Ładowanie domyślnych ustawień.")
                cls._config_data = cls._get_default_config()
            except Exception as e:
                game_logger.error(f"Nieoczekiwany błąd podczas wczytywania konfiguracji: {e}. Ładowanie domyślnych ustawień.")
                cls._config_data = cls._get_default_config()
        else:
            game_logger.info("Plik konfiguracyjny nie istnieje lub jest pusty. Ładowanie domyślnych ustawień.")
            cls._config_data = cls._get_default_config()
        cls._save_config()

    @classmethod
    def _save_config(cls):
        """
        Zapisuje bieżące ustawienia konfiguracji do pliku YAML.
        """
        try:
            with open(cls._config_file_path, 'w', encoding='utf-8') as f:
                yaml.dump(cls._config_data, f, default_flow_style=False, allow_unicode=True)
            game_logger.debug(f"Konfiguracja zapisana do {cls._config_file_path}")
        except Exception as e:
            game_logger.error(f"Błąd podczas zapisywania konfiguracji do pliku {cls._config_file_path}: {e}")

    @classmethod
    def _get_default_config(cls):
        """
        Zwraca domyślne ustawienia konfiguracji.
        """
        return {
            'board_size': DEFAULT_BOARD_SIZE,
            'target_value': DEFAULT_TARGET_VALUE,
            'initial_tiles': INITIAL_TILES,
            'probability_4': PROBABILITY_4,
            'min_board_size': MIN_BOARD_SIZE,
            'max_board_size': MAX_BOARD_SIZE,
            'available_target_values': AVAILABLE_TARGET_VALUES
        }

    def get_setting(self, key, default=None):
        """
        Pobiera wartość ustawienia.
        """
        return self._config_data.get(key, default)

    def set_setting(self, key, value):
        """
        Ustawia wartość ustawienia i zapisuje konfigurację.
        """
        self._config_data[key] = value
        self._save_config()

    def update_config(self, new_settings: dict):
        """
        Aktualizuje konfigurację na podstawie nowego słownika ustawień.
        """
        for key, value in new_settings.items():
            self._config_data[key] = value
        self._save_config()
        game_logger.info("Konfiguracja zaktualizowana.")

    @classmethod
    def get_all_settings(cls) -> dict:
        """
        Zwraca wszystkie aktualne ustawienia konfiguracji.
        """
        return cls._config_data.copy()