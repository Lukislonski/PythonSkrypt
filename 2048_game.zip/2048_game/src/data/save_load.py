#src/data/save_load.py

"""
Moduł odpowiedzialny za zapisywanie i wczytywanie stanu gry.
"""

import json
import os
import datetime
import hashlib
from src.core.board import Board
from src.utils.logger import game_logger

class SaveLoadManager:
    """
    Klasa zarządzająca zapisywaniem i wczytywaniem stanu gry do/z pliku JSON,
    z dodatkowym zabezpieczeniem sumą kontrolną.
    """

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.logger = game_logger
        self._ensure_save_dir_exists()

    def _ensure_save_dir_exists(self):
        """
        Upewnia się, że katalog dla pliku zapisu istnieje.
        """
        save_dir = os.path.dirname(self.file_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir)
            self.logger.info(f"Utworzono katalog zapisu: {save_dir}")

    def _generate_checksum(self, data: dict) -> str:
        """
        Generuje sumę kontrolną dla danych gry.
        Dane są sortowane, aby zapewnić spójność hasha.
        """
        json_string = json.dumps(data, sort_keys=True).encode('utf-8')
        return hashlib.sha256(json_string).hexdigest()

    def save_game(self, game_state: dict):
        """
        Zapisuje bieżący stan gry do pliku JSON, wraz z sumą kontrolną.
        """
        try:
            checksum = self._generate_checksum(game_state)
            save_data = {
                "checksum": checksum,
                "game_state": game_state
            }
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=4)
            self.logger.info(f"Stan gry został zapisany do: {self.file_path} z sumą kontrolną.")
            return True
        except Exception as e:
            self.logger.error(f"Błąd podczas zapisywania gry do {self.file_path}: {e}")
            return False

    def load_game(self) -> dict | None:
        """
        Wczytuje stan gry z pliku JSON i weryfikuje sumę kontrolną.
        """
        self.logger.debug(f"Rozpoczynanie wczytywania pliku: {self.file_path}")
        if not os.path.exists(self.file_path) or os.path.getsize(self.file_path) == 0:
            self.logger.warning(f"Brak pliku zapisu do wczytania: {self.file_path}")
            return None
        
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                loaded_data = json.load(f)
            
            stored_checksum = loaded_data.get("checksum")
            game_state = loaded_data.get("game_state")

            if not stored_checksum or not game_state:
                self.logger.error(f"Plik zapisu {self.file_path} jest uszkodzony lub ma nieprawidłowy format (brak sumy kontrolnej/stanu gry).")
                return None

            calculated_checksum = self._generate_checksum(game_state)

            if stored_checksum != calculated_checksum:
                self.logger.error(f"Plik zapisu {self.file_path} został zmodyfikowany! Suma kontrolna się nie zgadza.")
                return None
            
            self.logger.info(f"Stan gry został wczytany z: {self.file_path} i zweryfikowany.")
            return game_state
        except json.JSONDecodeError as e:
            self.logger.error(f"Błąd dekodowania JSON podczas wczytywania gry z {self.file_path}: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Nieoczekiwany błąd podczas wczytywania gry z {self.file_path}: {e}")
            return None

    def _serialize_board(self, board: list[list[int]]) -> list[list[int]]:
        return board

    def _deserialize_board(self, data: list[list[int]]) -> list[list[int]]:
        return data