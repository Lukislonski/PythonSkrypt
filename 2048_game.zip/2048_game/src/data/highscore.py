import os
import hashlib
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, DateTime
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from src.core.constants import HIGHSCORE_DB
from src.utils.logger import game_logger

Base = declarative_base()

class Highscore(Base):
    __tablename__ = 'highscores'

    id = Column(Integer, primary_key=True)
    score = Column(Integer, nullable=False)
    board_size = Column(Integer, nullable=False)
    target_value = Column(Integer, nullable=False)
    date = Column(DateTime, default=datetime.now)
    player_name = Column(String, nullable=True)
    checksum = Column(String, nullable=True)

    def __repr__(self):
        """
        Reprezentacja tekstowa obiektu Highscore.
        """
        return (f"<Highscore(score={self.score}, board_size={self.board_size}, "
                f"target_value={self.target_value}, player_name='{self.player_name}', "
                f"date='{self.date}', checksum='{self.checksum}')>")

    def to_dict(self):
        """
        Konwertuje obiekt Highscore na słownik.
        """
        return {
            "score": self.score,
            "board_size": self.board_size,
            "target_value": self.target_value,
            "player_name": self.player_name or "Anonim",
            "date": self.date.strftime("%Y-%m-%d %H:%M:%S"),
            "checksum": self.checksum
        }

class HighscoreManager:
    def __init__(self):
        """
        Inicjalizuje menedżera wyników.
        Tworzy katalog bazy danych, jeśli nie istnieje, inicjalizuje silnik bazy danych
        i sesję, a następnie tworzy tabele, jeśli są potrzebne.
        """
        db_dir = os.path.dirname(HIGHSCORE_DB)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir)
            game_logger.info(f"Utworzono katalog bazy danych: {db_dir}")

        self.engine = create_engine(f'sqlite:///{HIGHSCORE_DB}')
        self.Session = sessionmaker(bind=self.engine)
        self.logger = game_logger
        self._create_tables()

    def _create_tables(self):
        """
        Tworzy tabele w bazie danych, jeśli jeszcze nie istnieją.
        """
        Base.metadata.create_all(self.engine)
        self.logger.info("Tabele bazy danych highscore zostały sprawdzone/utworzone.")

    def compute_checksum(self, score, board_size, target_value, player_name):

        data_str = f"{score}{board_size}{target_value}{player_name}"
        return hashlib.sha256(data_str.encode()).hexdigest()

    def add_highscore(self, score: int, board_size: int, target_value: int, player_name: str = "Anonim"):
        """
        Dodaje nowy wynik do bazy danych.
        Oblicza sumę kontrolną i zapisuje rekord, obsługując potencjalne błędy.
        """
        session = self.Session()
        try:
            checksum = self.compute_checksum(score, board_size, target_value, player_name)
            new_highscore = Highscore(
                score=score,
                board_size=board_size,
                target_value=target_value,
                player_name=player_name,
                checksum=checksum,
                date=datetime.now()
            )
            session.add(new_highscore)
            session.commit()
            self.logger.info(f"Dodano nowy wynik: {score} przez {player_name}")
        except Exception as e:
            session.rollback()
            self.logger.error(f"Błąd podczas dodawania wyniku: {e}")
        finally:
            session.close()

    def get_top_highscores(self, limit=5):
        """
        Pobiera określoną liczbę najlepszych wyników z bazy danych, posortowanych malejąco.
        Weryfikuje sumy kontrolne, aby zwrócić tylko prawidłowe rekordy.
        """
        session = self.Session()
        try:
            results = session.query(Highscore).order_by(Highscore.score.desc()).limit(limit).all()
            valid = []
            for hs in results:
                player_name_for_checksum = hs.player_name if hs.player_name is not None else "Anonim"
                expected = self.compute_checksum(
                    hs.score, hs.board_size, hs.target_value, player_name_for_checksum
                )
                if hs.checksum == expected:
                    valid.append(hs)
                else:
                    self.logger.warning(f"Nieprawidłowa suma kontrolna dla rekordu {hs.id}, pomijam.")
            return [h.to_dict() for h in valid]
        except Exception as e:
            self.logger.error(f"Błąd podczas pobierania wyników: {e}")
            return []
        finally:
            session.close()

    def get_all_highscores(self):
        """
        Pobiera wszystkie wyniki z bazy danych, posortowane malejąco według wyniku.
        """
        session = self.Session()
        try:
            results = session.query(Highscore).order_by(Highscore.score.desc()).all()
            valid = []
            for hs in results:
                valid.append(hs.to_dict())
            return valid
        except Exception as e:
            self.logger.error(f"Błąd podczas pobierania wszystkich wyników: {e}")
            return []
        finally:
            session.close()

    def clear_all_highscores(self) -> bool:
        """
        Usuwa wszystkie rekordy wyników z bazy danych.
        Zwraca True, jeśli operacja się powiodła, False w przeciwnym razie.
        """
        session = self.Session()
        try:
            num_deleted = session.query(Highscore).delete()
            session.commit()
            self.logger.info(f"Usunięto {num_deleted} rekordów z rankingu.")
            return True
        except Exception as e:
            session.rollback()
            self.logger.error(f"Błąd podczas resetowania rankingu: {e}")
            return False
        finally:
            session.close()
