#src/utils/logger.py

"""
Moduł konfigurujący system logowania dla całej aplikacji.
Umożliwia zapisywanie logów do konsoli i do pliku.
"""

import logging
import os
from src.core.constants import LOG_FILE, UI_COLORS

log_dir = os.path.dirname(LOG_FILE)
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

class CustomFormatter(logging.Formatter):
    """
    Niestandardowy formatter do logów, dodający kolory dla wyjścia konsolowego.
    """
    
    FORMATS = {
        logging.DEBUG: f"{UI_COLORS['DEBUG']}%(asctime)s - %(name)s - %(levelname)s - %(message)s{UI_COLORS['RESET']}",
        logging.INFO: f"{UI_COLORS['INFO']}%(asctime)s - %(name)s - %(levelname)s - %(message)s{UI_COLORS['RESET']}",
        logging.WARNING: f"{UI_COLORS['WARNING']}%(asctime)s - %(name)s - %(levelname)s - %(message)s{UI_COLORS['RESET']}",
        logging.ERROR: f"{UI_COLORS['ERROR']}%(asctime)s - %(name)s - %(levelname)s - %(message)s{UI_COLORS['RESET']}",
        logging.CRITICAL: f"{UI_COLORS['CRITICAL']}%(asctime)s - %(name)s - %(levelname)s - %(message)s{UI_COLORS['RESET']}"
    }

    def format(self, record):
        """
        Formatuje rekord logu, dodając odpowiednie kolory.
        """
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)

def setup_logging(level=logging.INFO):
    """
    Konfiguruje system logowania dla całej aplikacji.
    """
    # Główny logger aplikacji
    logger = logging.getLogger('2048Game')
    logger.setLevel(level)

    # Zapobiega podwójnemu dodawaniu handlerów przy ponownym wywołaniu funkcji
    if not logger.handlers:
        # Handler do konsoli
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        console_handler.setFormatter(CustomFormatter())
        logger.addHandler(console_handler)

        # Handler do pliku
        file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

    return logger

game_logger = setup_logging()