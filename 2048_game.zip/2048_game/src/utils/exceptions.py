#src/utils/exceptions.py

"""
Moduł definiujący niestandardowe wyjątki dla gry 2048.
Pozwala na bardziej szczegółową i czytelną obsługę błędów.
"""

class GameException(Exception):
    """
    Ogólna klasa bazowa dla wszystkich niestandardowych wyjątków w grze 2048.
    """
    pass

class InvalidMoveException(GameException):
    """
    Wyjątek, gdy gracz próbuje wykonać nieprawidłowy ruch
    """
    pass

class SaveLoadException(GameException):
    """
    Wyjątek, gdy wystąpi problem podczas zapisu lub odczytu stanu gry.
    """
    pass

class ConfigurationError(GameException):
    """
    Wyjątek, gdy wystąpi błąd w konfiguracji gry.
    """
    pass

class GameLogicError(GameException):
    """
    Wyjątek, gdy wystąpi wewnętrzny błąd w logice gry.
    """
    pass

class QuitGameException(GameException):
    """
    Wyjątek, gdy użytkownik zdecyduje się wyjść z gry.
    """
    pass