import argparse
import yaml
from pathlib import Path

# Definiuje ścieżkę do pliku konfiguracyjnego YAML.
CONFIG_FILE = Path("config/settings.yaml")

def parse_args():
    """
    Umożliwia konfigurację gry za pomocą flag, takich jak nazwa gracza, poziom trudności,
    tryb dla dwóch graczy, tryb wyzwania oraz wymuszenie nowej gry.
    """
    parser = argparse.ArgumentParser(description="Gra 2048 z rozszerzeniami")
    parser.add_argument("--player", type=str, help="Nazwa gracza")
    parser.add_argument("--difficulty", choices=["easy", "medium", "hard"], help="Poziom trudności")
    parser.add_argument("--two-player", action="store_true", help="Tryb dla dwóch graczy")
    parser.add_argument("--challenge", action="store_true", help="Tryb wyzwania")
    parser.add_argument("--new", action="store_true", help="Wymuś nową grę")
    return parser.parse_args()

class ConfigManager:
    """
    Zarządza konfiguracją gry, w tym ładowaniem i zapisywaniem ustawień do pliku YAML.
    """
    def __init__(self):
        self.settings = self.load()

    def load(self):
        """
        Wczytuje ustawienia konfiguracji z pliku YAML.
        """
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return yaml.safe_load(f)
        return {}

    def save(self):
        """
        Zapisuje bieżące ustawienia konfiguracji do pliku YAML.
        """
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            yaml.dump(self.settings, f)

    def get(self, key, default=None):
        return self.settings.get(key, default)

    def set(self, key, value):
        self.settings[key] = value
        self.save()
