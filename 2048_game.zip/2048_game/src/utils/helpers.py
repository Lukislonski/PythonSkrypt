#src/utils/helpers.py

"""
Moduł zawierający użyteczne narzędzia i pomocnicze funkcje
dla aplikacji gry 2048.
"""

import os
import sys
import time
import functools
import logging
from src.utils.logger import game_logger
from src.core.constants import UI_COLORS, MSG_WELCOME, MSG_CONTROLS, MSG_SCORE

_global_renderer = None

def set_global_renderer(renderer):
    """
    Ustawia globalną instancję renderera konsoli.
    """
    global _global_renderer
    _global_renderer = renderer
    game_logger.debug("Globalny renderer ustawiony.")

def get_global_renderer():
    """
    Zwraca globalną instancję renderera konsoli.
    """
    if _global_renderer is None:
        game_logger.warning("Próba pobrania globalnego renderera przed jego ustawieniem.")
    return _global_renderer


def clear_console():
    """
    Czyści konsolę.
    """
    os.system('cls' if os.name == 'nt' else 'clear')

def exit_game():
    """
    Kończy działanie aplikacji.
    """
    game_logger.info("Zamykanie gry.")
    clear_console()
    print(f"{UI_COLORS['INFO']}Dziękujemy za grę! Do zobaczenia!{UI_COLORS['RESET']}")
    sys.exit()

def measure_time(func):
    """
    Dekorator mierzący czas wykonania funkcji.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()
        game_logger.debug(f"Funkcja {func.__name__} wykonana w {end_time - start_time:.4f} sekundy.")
        return result
    return wrapper

def log_function_call(func):
    """
    Dekorator logujący wywołanie funkcji i jej argumenty.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        args_repr = [repr(a) for a in args]
        kwargs_repr = [f"{k}={v!r}" for k, v in kwargs.items()]
        signature = ", ".join(args_repr + kwargs_repr)
        game_logger.debug(f"Wywołanie {func.__name__}({signature})")
        result = func(*args, **kwargs)
        game_logger.debug(f"Funkcja {func.__name__} zwróciła {result!r}")
        return result
    return wrapper

def display_welcome_screen(input_handler):
    """
    Wyświetla ekran powitalny i instrukcje.
    """
    clear_console()
    print(MSG_WELCOME)
    print("\n")
    print(MSG_CONTROLS)
    print("\nNaciśnij dowolny klawisz, aby rozpocząć...")
    input_handler.get_key()

def display_game_info(game_score: int, highscore: int, moves: int):
    """
    Wyświetla aktualny wynik, najlepszy wynik i liczbę ruchów.
    """
    print(MSG_SCORE.format(score=game_score, highscore=highscore, moves=moves))

def get_user_input(prompt: str, validation_func=None):
    """
    Pobiera dane wejściowe od użytkownika z opcjonalną walidacją.
    """
    while True:
        user_input = input(prompt).strip()
        if validation_func is None or validation_func(user_input):
            return user_input
        else:
            print(f"{UI_COLORS['WARNING']}Nieprawidłowe dane. Spróbuj ponownie.{UI_COLORS['RESET']}")

def validate_input(input_str: str) -> bool:
    """
    Podstawowa funkcja walidująca dane wejściowe (np. czy nie są puste).
    """
    return bool(input_str.strip())

def validate_board_size(size_str: str) -> bool:
    """
    Waliduje rozmiar planszy podany przez użytkownika.
    """
    try:
        size = int(size_str)
        from src.core.constants import MIN_BOARD_SIZE, MAX_BOARD_SIZE
        return MIN_BOARD_SIZE <= size <= MAX_BOARD_SIZE
    except ValueError:
        return False