#src/core/constants.py

"""
Moduł przechowujący stałe używane w grze 2048.
Definiuje rozmiary planszy, wartości docelowe,
oraz kody kolorów dla wyświetlania w konsoli.
"""

from colorama import Fore, Back, Style

# --- Ustawienia gry ---
DEFAULT_BOARD_SIZE = 4
MIN_BOARD_SIZE = 3
MAX_BOARD_SIZE = 6
AVAILABLE_BOARD_SIZES = list(range(MIN_BOARD_SIZE, MAX_BOARD_SIZE + 1))
DEFAULT_TARGET_VALUE = 2048
AVAILABLE_TARGET_VALUES = [512, 1024, 2048, 4096]
INITIAL_TILES = 2
PROBABILITY_4 = 0.1

# --- Ustawienia interfejsu użytkownika ---
TILE_COLORS = {
    0:    (Back.BLACK, Fore.WHITE),
    2:    (Back.WHITE, Fore.BLACK),
    4:    (Back.LIGHTYELLOW_EX, Fore.BLACK),
    8:    (Back.YELLOW, Fore.BLACK),
    16:   (Back.RED, Fore.WHITE),
    32:   (Back.LIGHTRED_EX, Fore.WHITE),
    64:   (Back.MAGENTA, Fore.WHITE),
    128:  (Back.LIGHTMAGENTA_EX, Fore.WHITE),
    256:  (Back.BLUE, Fore.WHITE),
    512:  (Back.LIGHTBLUE_EX, Fore.WHITE),
    1024: (Back.CYAN, Fore.WHITE),
    2048: (Back.LIGHTCYAN_EX, Fore.BLACK),
    4096: (Back.GREEN, Fore.WHITE),
}

# Kolory dla tekstu UI
UI_COLORS = {
    "HEADER": Style.BRIGHT + Fore.CYAN,
    "INFO": Fore.GREEN,
    "WARNING": Fore.YELLOW,
    "ERROR": Fore.RED,
    "DEBUG": Fore.WHITE,
    "CRITICAL": Back.RED + Fore.WHITE + Style.BRIGHT,
    "RESET": Style.RESET_ALL,
    "HIGHLIGHT": Style.BRIGHT + Fore.YELLOW,
    "MENU_OPTION": Fore.WHITE,
    "MENU_SELECTED": Back.BLUE + Fore.WHITE,
    "BOARD_BORDER": Fore.LIGHTBLACK_EX,
}

# --- Komunikaty dla użytkownika ---
MSG_WELCOME = f"{UI_COLORS['HEADER']}Witaj w grze 2048!{UI_COLORS['RESET']}"
MSG_CONTROLS = (
    f"{UI_COLORS['INFO']}Sterowanie:\n"
    f"  Strzałki (góra/dół/lewo/prawo) - Przesuń bloki\n"
    f"  U - Cofnij ruch (Undo)\n"
    f"  S - Zapisz grę\n"
    f"  L - Wczytaj grę\n"
    f"  M - Menu Główne\n"
    f"  Q - Wyjście z gry{UI_COLORS['RESET']}"
)
MSG_GAME_OVER = f"{UI_COLORS['ERROR']}Koniec gry! Brak możliwych ruchów.{UI_COLORS['RESET']}"
MSG_WIN = f"{UI_COLORS['HIGHLIGHT']}Gratulacje! Osiągnąłeś {DEFAULT_TARGET_VALUE}!{UI_COLORS['RESET']}"
MSG_INVALID_MOVE = f"{UI_COLORS['WARNING']}Nieprawidłowy ruch! Spróbuj ponownie.{UI_COLORS['RESET']}"
MSG_SAVE_SUCCESS = f"{UI_COLORS['INFO']}Gra została zapisana.{UI_COLORS['RESET']}"
MSG_LOAD_SUCCESS = f"{UI_COLORS['INFO']}Gra została wczytana.{UI_COLORS['RESET']}"
MSG_NO_SAVE_GAME = f"{UI_COLORS['WARNING']}Brak zapisanej gry do wczytania.{UI_COLORS['RESET']}"
MSG_SCORE = f"{UI_COLORS['INFO']}Wynik: {{score}} | Najlepszy: {{highscore}} | Ruchy: {{moves}}{UI_COLORS['RESET']}"

# --- Ścieżki do plików ---
SAVE_FILE = 'data/autosave.json'
HIGHSCORE_DB = 'data/highscores.db'
CONFIG_FILE = 'config/settings.yaml'
LOG_FILE = 'logs/game.log'
REPORTS_DIR = 'reports/'
GAME_MODES_MAP = {}
AUTOSAVE_FILE = 'data/autosave_game.json'