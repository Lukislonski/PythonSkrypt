import logging
from src.core.game import Game
from src.ui.menu import Menu
from src.utils.config_loader import ConfigManager
from src.utils.renderer import ConsoleRenderer

class MainApp:
    def __init__(self, initial_config=None, force_new_game=False):
        """
        Konstruktor klasy MainApp.
        Inicjalizuje menedżera konfiguracji, renderer konsoli, menu oraz instancję gry.
        Obsługuje również wymuszone rozpoczęcie nowej gry lub wczytanie istniejącej.
        """
        self.logger = logging.getLogger("2048Game")
        self.logger.setLevel(logging.INFO)
        self.config_manager = ConfigManager(initial_config)
        self.renderer = ConsoleRenderer()
        self.menu = Menu(self.renderer, self.config_manager)
        self.game = Game(
            config_manager=self.config_manager,
            renderer=self.renderer,
            logger=self.logger,
            player_name=self.config_manager.get("player_name", "Gracz"),
            difficulty=self.config_manager.get("difficulty", "medium"),
            two_player=self.config_manager.get("two_player", False),
            challenge_mode=self.config_manager.get("challenge_mode", False)
        )
        if force_new_game:
            self.game.start_new_game()
        else:
            self.game.load_or_start()

    def run(self):
        """
        Uruchamia główną pętlę aplikacji, wyświetlając główne menu gry.
        Odpowiada za inicjowanie interakcji użytkownika z menu.
        """
        self.menu.display_main_menu(self.game)
