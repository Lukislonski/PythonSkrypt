# src/core/game.py

"""
Główny moduł gry 2048.
Koordynuje interakcje między planszą, wynikami, statystykami i trybami gry.
"""

import random
import logging
from src.core.board import Board
from src.modes.game_mode import StandardGameMode
from src.utils.helpers import log_function_call, measure_time, get_user_input
from src.core.constants import INITIAL_TILES, PROBABILITY_4, MSG_WIN, MSG_GAME_OVER, UI_COLORS, DEFAULT_TARGET_VALUE, DEFAULT_BOARD_SIZE
from src.utils.exceptions import InvalidMoveException, GameLogicError

class Game:
    def __init__(self, config_manager, game_stats, highscore_manager, manual_save_load_manager, autosave_load_manager, logger, input_handler):
        """
        Inicjalizuje główny obiekt gry.
        Ustawia menedżery konfiguracji, statystyk, wyników, zapisu/odczytu, loggera oraz obsługę wejścia.
        Tworzy nową grę lub próbuje wczytać istniejącą.
        """
        self.config_manager = config_manager
        self.game_stats = game_stats
        self.highscore_manager = highscore_manager
        self.manual_save_load_manager = manual_save_load_manager
        self.autosave_load_manager = autosave_load_manager
        self.logger = logger
        self.input_handler = input_handler
        self.board = None
        self.undo_stack = []
        self.current_mode = StandardGameMode(self)

        # Próba wczytania zapisu gry przy starcie
        if not self.load_game():
            self.start_new_game()

    @log_function_call
    def start_new_game(self, board_size=None):
        """
        Rozpoczyna nową grę.
        Inicjalizuje planszę o podanym rozmiarze (lub domyślnym), dodaje początkowe kafelki,
        resetuje statystyki gry i stos cofania ruchów, a następnie automatycznie zapisuje stan gry.
        """
        if board_size is None:
            board_size = self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE)

        self.board = Board(size=board_size)

        for _ in range(INITIAL_TILES):
            self.board.add_random_tile()

        self.game_stats.reset_stats()
        self.undo_stack = []
        self.logger.info(f"Plansza {board_size}x{board_size} zainicjalizowana.")
        self._autosave_game()

    @measure_time
    @log_function_call
    def move(self, direction: str) -> bool:
        """
        Wykonuje ruch na planszy w podanym kierunku.
        """
        self.save_state()
        try:
            board_changed, points_gained = self.current_mode.handle_move(direction)
            if not board_changed:
                self.undo_stack.pop()
                self.logger.debug("Ruch nie spowodował zmian na planszy.")
            else:
                self._autosave_game()
            return board_changed
        except InvalidMoveException as e:
            self.undo_stack.pop()
            self.logger.warning(f"Nieprawidłowy ruch: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Nieoczekiwany błąd podczas ruchu: {e}")
            raise GameLogicError(f"Błąd logiki gry podczas ruchu: {e}")

    @log_function_call
    def add_random_tile(self):
        """
        Dodaje losowy kafelek (2 lub 4) w pustym miejscu na planszy.
        """
        self.board.add_random_tile()
        self.logger.debug("Dodano losowy kafelek do planszy.")

    @log_function_call
    def save_state(self):
        """
        Zapisuje bieżący stan planszy do stosu cofania ruchów.
        Utrzymuje limit 10 ostatnich stanów.
        """
        if len(self.undo_stack) >= 10:
            self.undo_stack.pop(0)
        self.undo_stack.append(self.board.get_board_state())
        self.logger.debug("Stan planszy zapisany do stosu undo.")

    @log_function_call
    def undo_move(self):
        """
        Cofa ostatni ruch, przywracając poprzedni stan planszy ze stosu cofania.
        Zmniejsza liczbę wykonanych ruchów i automatycznie zapisuje grę.
        """
        if self.undo_stack:
            previous_state = self.undo_stack.pop()
            self.board.set_board_state(previous_state)
            self.game_stats.decrement_moves()
            self.logger.info("Cofnięto ostatni ruch.")
            self._autosave_game()
            return True
        self.logger.warning("Brak ruchów do cofnięcia.")
        return False

    @log_function_call
    def check_win(self) -> bool:
        """
        Sprawdza, czy warunek wygranej został spełniony w bieżącym trybie gry.
        """
        return self.current_mode.check_win_condition()

    @log_function_call
    def check_game_over(self) -> bool:
        """
        Sprawdza, czy gra się zakończyła (brak możliwych ruchów) w bieżącym trybie gry.
        """
        return self.current_mode.is_game_over()

    @log_function_call
    def handle_win(self):
        """
        Loguje zwycięstwo, pobiera imię gracza i dodaje wynik do rankingu.
        """
        self.logger.info(MSG_WIN)
        current_score = self.game_stats.get_score()
        try:
            current_board_size = int(self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE))
            current_target_value = int(self.config_manager.get_setting('target_value', DEFAULT_TARGET_VALUE))
        except ValueError:
            self.logger.error("Błąd: Rozmiar planszy lub wartość docelowa z konfiguracji nie są liczbami całkowitymi. Używam wartości domyślnych.")
            current_board_size = DEFAULT_BOARD_SIZE
            current_target_value = DEFAULT_TARGET_VALUE
        
        player_name = get_user_input(
            f"{UI_COLORS['INFO']}Gratulacje! Podaj swoje imię (maks. 20 znaków): {UI_COLORS['RESET']}",
            lambda x: 1 <= len(x) <= 20
        )
        if not player_name:
            player_name = "Anonim"

        self.highscore_manager.add_highscore(current_score, current_board_size, current_target_value, player_name)
        self.logger.info(f"Wynik zwycięstwa ({current_score}) przez {player_name} dodany do rankingu.")
        self._autosave_game()
        self.autosave_load_manager.save_game({})

    @log_function_call
    def handle_game_over(self):
        """
        Loguje koniec gry, pobiera imię gracza i dodaje wynik do rankingu.
        """
        self.logger.info(MSG_GAME_OVER)
        current_score = self.game_stats.get_score()
        try:
            current_board_size = int(self.config_manager.get_setting('board_size', DEFAULT_BOARD_SIZE))
            current_target_value = int(self.config_manager.get_setting('target_value', DEFAULT_TARGET_VALUE))
        except ValueError:
            self.logger.error("Błąd: Rozmiar planszy lub wartość docelowa z konfiguracji nie są liczbami całkowitymi. Używam wartości domyślnych.")
            current_board_size = DEFAULT_BOARD_SIZE
            current_target_value = DEFAULT_TARGET_VALUE

        player_name = get_user_input(
            f"{UI_COLORS['INFO']}Koniec gry! Podaj swoje imię (maks. 20 znaków): {UI_COLORS['RESET']}",
            lambda x: 1 <= len(x) <= 20
        )
        if not player_name:
            player_name = "Anonim"

        self.highscore_manager.add_highscore(current_score, current_board_size, current_target_value, player_name)
        self.logger.info(f"Wynik końcowy ({current_score}) przez {player_name} dodany do rankingu.")
        self._autosave_game()
        self.autosave_load_manager.save_game({})

    def _get_game_state(self) -> dict:
        """
        Metoda pomocnicza do pobierania bieżącego stanu gry.
        """
        return {
            'board': self.board.get_board(),
            'score': self.game_stats.get_score(),
            'moves': self.game_stats.get_moves(),
            'max_tile': self.game_stats.get_max_tile(),
            'undo_stack': self.undo_stack,
            'config': self.config_manager.get_all_settings(),
            'current_mode': self.current_mode.get_name()
        }

    @log_function_call
    def save_game(self):
        """
        Ręcznie zapisuje bieżący stan gry do pliku.
        """
        try:
            game_state = self._get_game_state()
            self.manual_save_load_manager.save_game(game_state)
            self.logger.info("Stan gry został zapisany ręcznie.")
        except Exception as e:
            self.logger.error(f"Błąd podczas ręcznego zapisywania gry: {e}")

    @log_function_call
    def _autosave_game(self):
        """
        Automatycznie zapisuje bieżący stan gry do pliku autosave.
        """
        try:
            game_state = self._get_game_state()
            self.autosave_load_manager.save_game(game_state)
            self.logger.debug("Stan gry został automatycznie zapisany.")
        except Exception as e:
            self.logger.error(f"Błąd podczas automatycznego zapisywania gry: {e}")

    @log_function_call
    def load_game(self) -> bool:
        """
        Wczytuje stan gry z pliku autosave lub ręcznego zapisu.
        """
        self.logger.debug("Rozpoczynanie procesu wczytywania gry.")
        try:
            self.logger.debug(f"Próba wczytania z autosave: {self.autosave_load_manager.file_path}")
            loaded_state = self.autosave_load_manager.load_game()

            if not loaded_state:
                self.logger.debug(f"Autosave nie znaleziony. Próba wczytania zapisu ręcznego: {self.manual_save_load_manager.file_path}")
                loaded_state = self.manual_save_load_manager.load_game()

            if loaded_state:
                self.logger.debug(f"Wczytany stan: {loaded_state}")
                self.board = Board(size=len(loaded_state['board']))
                self.board.set_board(loaded_state['board'])
                self.game_stats.set_score(loaded_state['score'])
                self.game_stats.set_moves(loaded_state['moves'])
                self.game_stats.update_max_tile(loaded_state['max_tile'])
                self.undo_stack = loaded_state.get('undo_stack', [])

                config = loaded_state.get('config', {})
                if config:
                    self.config_manager.update_config(config)

                self.set_current_mode(StandardGameMode(self))
                return True
            else:
                self.logger.warning("Nie udało się wczytać zapisu gry.")
                return False
        except Exception as e:
            self.logger.error(f"Błąd podczas wczytywania gry: {e}")
            return False

    @log_function_call
    def set_current_mode(self, mode_instance: StandardGameMode):
        """
        Ustawia bieżący tryb gry na podaną instancję trybu.
        """
        self.current_mode = mode_instance
        self.logger.info(f"Ustawiono tryb gry na: {self.current_mode.get_name()}")
