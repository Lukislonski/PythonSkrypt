#src/core/board.py

"""
Moduł definiujący klasę Board, która zarządza logiką planszy gry 2048.
"""

import random
from src.utils.logger import game_logger
from src.core.constants import PROBABILITY_4, DEFAULT_BOARD_SIZE

class Board:
    """
    Reprezentuje planszę gry 2048 i zarządza jej logiką.
    """
    def __init__(self, size=DEFAULT_BOARD_SIZE):
        self.size = size
        self.board = [[0 for _ in range(size)] for _ in range(size)]
        self.logger = game_logger
        self.logger.info(f"Plansza {self.size}x{self.size} zainicjalizowana.")

    def get_board(self) -> list[list[int]]:
        """
        Zwraca aktualny stan planszy.
        """
        return self.board

    def get_board_state(self) -> list[list[int]]:
        """
        Zwraca kopię aktualnego stanu planszy (do cofania ruchów).
        """
        return [row[:] for row in self.board]

    def set_board_state(self, state: list[list[int]]):
        """
        Ustawia stan planszy na podstawie podanego stanu (do cofania ruchów).
        """
        self.board = [row[:] for row in state]

    def set_board(self, new_board: list[list[int]]):
        """
        Ustawia planszę na nowy stan. Używane głównie przy wczytywaniu gry.
        """
        if len(new_board) == self.size and all(len(row) == self.size for row in new_board):
            self.board = [row[:] for row in new_board]
            self.logger.debug("Plansza ustawiona na nowy stan.")
        else:
            self.logger.error("Nieprawidłowy rozmiar planszy do ustawienia.")
            raise ValueError("Nieprawidłowy rozmiar planszy do ustawienia.")

    def add_random_tile(self, num_tiles=1, value=None):
        """
        Dodaje losowy kafelek (2 lub 4) do pustej komórki na planszy.
        """
        empty_cells = self._get_empty_cells()
        if not empty_cells:
            self.logger.debug("Brak pustych komórek do dodania kafelka.")
            return False

        for _ in range(num_tiles):
            if not empty_cells: break
            
            row, col = random.choice(empty_cells)
            empty_cells.remove((row, col))

            if value is None:
                tile_value = 4 if random.random() < PROBABILITY_4 else 2
            else:
                tile_value = value
                
            self.board[row][col] = tile_value
            self.logger.debug(f"Dodano kafelek {tile_value} w ({row}, {col}).")
        return True

    def _get_empty_cells(self) -> list[tuple[int, int]]:
        """
        Zwraca listę pustych komórek na planszy (wiersz, kolumna).
        """
        empty_cells = []
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c] == 0:
                    empty_cells.append((r, c))
        return empty_cells;

    def move_tiles(self, direction: str) -> tuple[bool, int]:
        """
        Przesuwa kafelki na planszy w podanym kierunku i łączy je.
        Zwraca True, jeśli plansza uległa zmianie.
        """
        board_changed = False
        points_gained = 0
        original_board = self.get_board_state()

        if direction == 'up':
            for col in range(self.size):
                points_gained += self._move_and_merge_column(col, -1)
        elif direction == 'down':
            for col in range(self.size):
                points_gained += self._move_and_merge_column(col, 1)
        elif direction == 'left':
            for row in range(self.size):
                points_gained += self._move_and_merge_row(row, -1)
        elif direction == 'right':
            for row in range(self.size):
                points_gained += self._move_and_merge_row(row, 1)
        else:
            self.logger.warning(f"Nieznany kierunek ruchu: {direction}")
            return False, 0
        
        if original_board != self.board:
            board_changed = True
            self.logger.debug(f"Plansza zmieniła się po ruchu {direction}.")
        else:
            self.logger.debug(f"Plansza nie zmieniła się po ruchu {direction}.")

        return board_changed, points_gained

    def _move_and_merge_row(self, row: int, direction: int) -> int:
        """
        Przesuwa i łączy kafelki w danym wierszu.
        direction: -1 dla lewo, 1 dla prawo.
        """
        line = self.board[row]
        new_line = [0] * self.size
        points_gained_in_line = 0
        idx = 0 if direction == -1 else self.size - 1
        step = 1 if direction == -1 else -1

        for i in range(self.size) if direction == -1 else range(self.size - 1, -1, -1):
            if line[i] != 0:
                new_line[idx] = line[i]
                idx += step

        # Scalanie
        for i in range(self.size - 1) if direction == -1 else range(self.size - 1, 0, -1):
            current_idx = i if direction == -1 else i - 1
            next_idx = i + 1 if direction == -1 else i
            if new_line[current_idx] == new_line[next_idx] and new_line[current_idx] != 0:
                new_line[current_idx] *= 2
                points_gained_in_line += new_line[current_idx]
                new_line[next_idx] = 0
        
        # Ponowne przesunięcie po scalaniu
        final_line = [0] * self.size
        idx = 0 if direction == -1 else self.size - 1
        for i in range(self.size) if direction == -1 else range(self.size - 1, -1, -1):
            if new_line[i] != 0:
                final_line[idx] = new_line[i]
                idx += step
        
        self.board[row] = final_line
        return points_gained_in_line


    def _move_and_merge_column(self, col: int, direction: int) -> int:
        """
        Przesuwa i łączy kafelki w danej kolumnie.
        direction: -1 dla góra, 1 dla dół.
        """
        line = [self.board[row][col] for row in range(self.size)]
        new_line = [0] * self.size
        points_gained_in_line = 0
        idx = 0 if direction == -1 else self.size - 1
        step = 1 if direction == -1 else -1

        for i in range(self.size) if direction == -1 else range(self.size - 1, -1, -1):
            if line[i] != 0:
                new_line[idx] = line[i]
                idx += step

        # Scalanie
        for i in range(self.size - 1) if direction == -1 else range(self.size - 1, 0, -1):
            current_idx = i if direction == -1 else i - 1
            next_idx = i + 1 if direction == -1 else i
            if new_line[current_idx] == new_line[next_idx] and new_line[current_idx] != 0:
                new_line[current_idx] *= 2
                points_gained_in_line += new_line[current_idx]
                new_line[next_idx] = 0
        
        # Ponowne przesunięcie po scalaniu
        final_line = [0] * self.size
        idx = 0 if direction == -1 else self.size - 1
        for i in range(self.size) if direction == -1 else range(self.size - 1, -1, -1):
            if new_line[i] != 0:
                final_line[idx] = new_line[i]
                idx += step

        for row in range(self.size):
            self.board[row][col] = final_line[row]
        return points_gained_in_line

    def has_valid_moves(self) -> bool:
        """
        Sprawdza, czy na planszy są jeszcze możliwe jakiekolwiek ruchy.
        """
        # Sprawdź, czy są puste komórki
        if self._get_empty_cells():
            return True

        # Sprawdź, czy są sąsiednie kafelki, które można połączyć
        for r in range(self.size):
            for c in range(self.size):
                current_tile = self.board[r][c]
                if current_tile == 0:
                    continue

                # Sprawdź sąsiadów w prawo i w dół
                if c + 1 < self.size and self.board[r][c + 1] == current_tile:
                    return True
                if r + 1 < self.size and self.board[r + 1][c] == current_tile:
                    return True
        
        return False

    def get_max_tile(self) -> int:
        """
        Skanuje planszę i zwraca najwyższą wartość kafelka.
        """
        max_val = 0
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r][c] > max_val:
                    max_val = self.board[r][c]
        return max_val