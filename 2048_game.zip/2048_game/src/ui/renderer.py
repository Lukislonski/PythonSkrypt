from colorama import Fore, Style, init
init(autoreset=True)

class ConsoleRenderer:
    """
    Klasa odpowiedzialna za renderowanie elementów gry (planszy, wiadomości, menu)
    w konsoli tekstowej, używając kolorów dla lepszej czytelności.
    """
    def __init__(self):
        """
        Inicjalizuje obiekt ConsoleRenderer.
        """
        pass

    def render_board(self, board):
        """
        Renderuje aktualny stan planszy gry w konsoli.
        Każdy kafelek jest kolorowany w zależności od jego wartości.
        """
        for row in board.grid:
            print(" | ".join(self._color_tile(val) for val in row))
        print()

    def render_message(self, msg):
        """
        Wyświetla ogólną wiadomość tekstową w konsoli.
        """
        print(msg)

    def _color_tile(self, value):
        """
        Przypisuje różne kolory do różnych wartości kafelków.
        """
        if value == 0:
            return "    "
        colors = {
            2: Fore.BLUE,
            4: Fore.CYAN,
            8: Fore.GREEN,
            16: Fore.YELLOW,
            32: Fore.MAGENTA,
            64: Fore.RED,
            128: Fore.LIGHTBLUE_EX,
            256: Fore.LIGHTCYAN_EX,
            512: Fore.LIGHTGREEN_EX,
            1024: Fore.LIGHTYELLOW_EX,
            2048: Fore.LIGHTRED_EX
        }
        return f"{colors.get(value, Fore.WHITE)}{str(value).center(4)}{Style.RESET_ALL}"
