#src/ui/menu.py

"""
Moduł odpowiedzialny za wyświetlanie menu gry i obsługę interakcji z użytkownikiem.
"""

import sys
from src.core.constants import UI_COLORS, AVAILABLE_BOARD_SIZES, AVAILABLE_TARGET_VALUES
from src.utils.helpers import clear_console, get_user_input, validate_input, validate_board_size
from src.utils.logger import game_logger

class Menu:
    """
    Klasa obsługująca wyświetlanie menu głównego, menu opcji i najlepszych wyników.
    """

    def __init__(self, renderer, input_handler, config_manager, highscore_manager, game):
        """
        Inicjalizuje obiekt Menu.
        Przyjmuje renderer, handler wejścia, menedżery konfiguracji i wyników oraz obiekt gry.
        """
        self.renderer = renderer
        self.input_handler = input_handler
        self.config_manager = config_manager
        self.highscore_manager = highscore_manager
        self.game = game
        self.logger = game_logger

    def display_main_menu(self) -> str:
        """
        Wyświetla główne menu gry i pobiera wybór użytkownika.
        Pętla trwa, dopóki użytkownik nie dokona prawidłowego wyboru.
        """
        while True:
            self.renderer.clear_screen()
            self.renderer.render_header("MENU GŁÓWNE")
            self.renderer.render_menu_option("1. Nowa gra")
            self.renderer.render_menu_option("2. Wczytaj grę")
            self.renderer.render_menu_option("3. Opcje")
            self.renderer.render_menu_option("4. Najlepsze wyniki")
            self.renderer.render_menu_option("5. Statystyki")
            self.renderer.render_menu_option("6. Wybór trybu gry")
            self.renderer.render_menu_option("7. Wyjście")

            choice = get_user_input(f"{UI_COLORS['MENU_OPTION']}Wybierz opcję: {UI_COLORS['RESET']}",
                                    lambda x: x.isdigit() and 1 <= int(x) <= 7)
            if choice:
                return choice
            else:
                self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowy wybór. Spróbuj ponownie." + UI_COLORS['RESET'])
                self.input_handler.get_key()

    def display_options_menu(self) -> str:
        """
        Wyświetla menu opcji gry i pobiera wybór użytkownika.
        Pozwala na zmianę rozmiaru planszy, wartości docelowej oraz resetowanie najlepszych wyników.
        """
        while True:
            self.renderer.clear_screen()
            self.renderer.render_header("OPCJE")
            self.renderer.render_menu_option(f"1. Zmień rozmiar planszy (Aktualny: {self.config_manager.get_setting('board_size')})")
            self.renderer.render_menu_option(f"2. Zmień wartość docelową (Aktualna: {self.config_manager.get_setting('target_value')})")
            self.renderer.render_menu_option("3. Resetuj najlepsze wyniki")
            self.renderer.render_menu_option("4. Powrót do menu głównego")
            
            choice = get_user_input(f"{UI_COLORS['MENU_OPTION']}Wybierz opcję: {UI_COLORS['RESET']}",
                                    lambda x: x.isdigit() and 1 <= int(x) <= 4)
            if choice:
                if choice == '1':
                    while True:
                        self.renderer.clear_screen()
                        self.renderer.render_header("ZMIANA ROZMIARU PLANSZY")
                        self.renderer.render_message(f"Dostępne rozmiary: {', '.join(map(str, AVAILABLE_BOARD_SIZES))}")
                        new_size_str = get_user_input(
                            f"{UI_COLORS['MENU_OPTION']}Podaj nowy rozmiar planszy (np. 4): {UI_COLORS['RESET']}",
                            validate_board_size
                        )
                        if new_size_str:
                            try:
                                new_size = int(new_size_str)
                                self.config_manager.set_setting('board_size', new_size)
                                self.renderer.render_message(UI_COLORS['INFO'] + f"Rozmiar planszy zmieniony na {new_size}x{new_size}." + UI_COLORS['RESET'])
                                self.input_handler.get_key()
                                break
                            except ValueError:
                                self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowy rozmiar planszy. Podaj liczbę." + UI_COLORS['RESET'])
                                self.input_handler.get_key()
                        else:
                            self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowy rozmiar planszy. Spróbuj ponownie." + UI_COLORS['RESET'])
                            self.input_handler.get_key()
                elif choice == '2':
                    while True:
                        self.renderer.clear_screen()
                        self.renderer.render_header("ZMIANA WARTOŚCI DOCELOWEJ")
                        self.renderer.render_message(f"Dostępne wartości docelowe: {', '.join(map(str, AVAILABLE_TARGET_VALUES))}")
                        new_target_str = get_user_input(
                            f"{UI_COLORS['MENU_OPTION']}Podaj nową wartość docelową (np. 2048): {UI_COLORS['RESET']}",
                            lambda x: x.isdigit() and int(x) in AVAILABLE_TARGET_VALUES
                        )
                        if new_target_str:
                            try:
                                new_target = int(new_target_str)
                                self.config_manager.set_setting('target_value', new_target)
                                self.renderer.render_message(UI_COLORS['INFO'] + f"Wartość docelowa zmieniona na {new_target}." + UI_COLORS['RESET'])
                                self.input_handler.get_key()
                                break
                            except ValueError:
                                self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowa wartość docelowa. Podaj liczbę." + UI_COLORS['RESET'])
                                self.input_handler.get_key()
                        else:
                            self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowa wartość docelowa. Spróbuj ponownie." + UI_COLORS['RESET'])
                            self.input_handler.get_key()
                elif choice == '3':
                    self.renderer.render_message(UI_COLORS['WARNING'] + "Czy na pewno chcesz zresetować wszystkie najlepsze wyniki? (Y/N)" + UI_COLORS['RESET'])
                    confirm = self.input_handler.get_key()
                    if confirm.upper() in ['Y', 'T']:
                        if self.highscore_manager.clear_all_highscores():
                            self.renderer.render_message(UI_COLORS['INFO'] + "Wszystkie najlepsze wyniki zostały zresetowane." + UI_COLORS['RESET'])
                        else:
                            self.renderer.render_message(UI_COLORS['ERROR'] + "Wystąpił błąd podczas resetowania wyników." + UI_COLORS['RESET'])
                    else:
                        self.renderer.render_message(UI_COLORS['INFO'] + "Resetowanie wyników anulowane." + UI_COLORS['RESET'])
                    self.input_handler.get_key()
                    return None
                return choice
            else:
                self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowy wybór. Spróbuj ponownie." + UI_COLORS['RESET'])
                self.input_handler.get_key()

    def display_highscores(self):
        """
        Wyświetla listę najlepszych wyników.
        """
        highscores = self.highscore_manager.get_top_highscores()
        self.renderer.render_header("NAJLEPSZE WYNIKI")

        if not highscores:
            self.renderer.render_text("Brak zapisanych wyników.")
        else:
            for i, entry in enumerate(highscores, start=1):
                player = entry.get('player_name', 'Anonim')
                score = entry.get('score', 0)
                board = entry.get('board_size', 4)
                target = entry.get('target_value', 2048)
                date = entry.get('date', '---')

                self.renderer.render_message(
                    f"{i}. {player} | Wynik: {score} | Plansza: {board}x{board} | Cel: {target} | Data: {date}"
                )
        self.renderer.render_message("\nNaciśnij dowolny klawisz, aby wrócić do menu...")
        self.input_handler.get_key()

    def ask_to_continue(self) -> bool:
        """
        Pyta użytkownika, czy chce kontynuować grę po zwycięstwie.
        Czeka na odpowiedź 'Y' (Tak) lub 'N' (Nie).
        Zwraca True, jeśli użytkownik chce kontynuować, False w przeciwnym razie.
        """
        self.renderer.render_message(UI_COLORS['INFO'] + "Czy chcesz kontynuować grę (Y/N)?" + UI_COLORS['RESET'])
        while True:
            response = self.input_handler.get_key()
            if response.upper() in ['Y', 'T']:
                self.logger.info("Gracz zdecydował się kontynuować grę po zwycięstwie.")
                return True
            elif response.upper() in ['N']:
                self.logger.info("Gracz zdecydował się zakończyć grę po zwycięstwie.")
                return False
            else:
                self.renderer.render_message(UI_COLORS['WARNING'] + "Nieprawidłowy wybór. Wpisz Y (Tak) lub N (Nie)." + UI_COLORS['RESET'])
