# src/ui/input_handler.py

"""
Moduł odpowiedzialny za obsługę wejścia użytkownika z klawiatury.
Zapewnia odczyt pojedynczego znaku bez konieczności naciskania Enter.
"""

import sys
import os
import logging
from src.utils.logger import game_logger

class InputHandler:
    """
    Klasa obsługująca odczyt klawiszy z konsoli.
    """
    def __init__(self):
        """
        Inicjalizuje obiekt InputHandler.
        Ustawia logger dla klasy.
        """
        self.logger = game_logger

    def get_key(self):
        """
        Odczytuje pojedynczy znak z klawiatury bez czekania na Enter.
        Obsługuje klawisze strzałek i standardowe znaki.
        """
        if os.name == 'nt':
            import msvcrt
            try:
                key_bytes = msvcrt.getch()
                self.logger.debug(f"Raw key bytes from msvcrt.getch(): {key_bytes}")

                if key_bytes == b'\xe0':
                    key_code_bytes = msvcrt.getch()
                    self.logger.debug(f"Arrow key code bytes: {key_code_bytes}")
                    arrow_key_map = {
                        b'H': 'UP',
                        b'P': 'DOWN',
                        b'K': 'LEFT',
                        b'M': 'RIGHT'
                    }
                    if key_code_bytes in arrow_key_map:
                        returned_key = arrow_key_map[key_code_bytes]
                        self.logger.debug(f"InputHandler.get_key() returns: '{returned_key}'")
                        return returned_key
                    else:
                        self.logger.warning(f"Nierozpoznany kod klawisza strzałki (bajty): {key_code_bytes}")
                        self.logger.debug("InputHandler.get_key() returns: 'UNKNOWN_ARROW'")
                        return 'UNKNOWN_ARROW'
                else:
                    try:
                        decoded_key = key_bytes.decode('utf-8')
                        self.logger.debug(f"InputHandler.get_key() returns: '{decoded_key.upper()}'")
                        return decoded_key.upper()
                    except UnicodeDecodeError:
                        self.logger.warning(f"Niezdekodowany klawisz (UnicodeDecodeError): {key_bytes}. Traktowany jako nieznany.")
                        self.logger.debug("InputHandler.get_key() returns: 'UNRECOGNIZED_CHAR'")
                        return 'UNRECOGNIZED_CHAR'
            except Exception as e:
                self.logger.error(f"Nieoczekiwany błąd w InputHandler.get_key() (Windows): {e}")
                self.logger.debug("InputHandler.get_key() returns: 'ERROR_KEY'")
                return 'ERROR_KEY'

        else:
            import termios
            import tty
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            try:
                tty.setraw(sys.stdin.fileno())
                ch = sys.stdin.read(1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

            if ch == '\x1b':
                try:
                    ch += sys.stdin.read(2)
                except Exception:
                    pass

                arrow_key_map_posix = {
                    '\x1b[A': 'UP',
                    '\x1b[B': 'DOWN',
                    '\x1b[C': 'RIGHT',
                    '\x1b[D': 'LEFT'
                }
                if ch in arrow_key_map_posix:
                    returned_key = arrow_key_map_posix[ch]
                    self.logger.debug(f"InputHandler.get_key() returns: '{returned_key}'")
                    return returned_key
                else:
                    self.logger.warning(f"Nierozpoznana sekwencja klawisza strzałki (POSIX): {ch}")
                    self.logger.debug("InputHandler.get_key() returns: 'UNKNOWN_ARROW'")
                    return 'UNKNOWN_ARROW'
            
            self.logger.debug(f"InputHandler.get_key() returns: '{ch.upper()}'")
            return ch.upper()
        
    def get_input_char(self, prompt=""):
        """
        Pobiera linię tekstu od użytkownika, wyświetlając opcjonalny prompt.
        """
        return input(prompt).strip().upper()
