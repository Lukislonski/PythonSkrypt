#src/ui/console_renderer.py

"""
Moduł odpowiedzialny za renderowanie stanu gry 2048 w konsoli.
Obsługuje wyświetlanie planszy, menu, wiadomości i animacji.
"""

import os
import time
from colorama import Fore, Back, Style, init
from src.core.constants import TILE_COLORS, UI_COLORS, DEFAULT_BOARD_SIZE
from src.utils.logger import game_logger

# Inicjalizacja colorama, aby kolory działały na różnych terminalach
init(autoreset=True)

class ConsoleRenderer:
    """
    Klasa odpowiedzialna za renderowanie planszy gry 2048 i innych elementów UI
    w konsoli tekstowej.
    """

    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.logger = game_logger
        self.tile_width = 6

    def clear_screen(self):
        """
        Czyści ekran konsoli.
        """
        os.system('cls' if os.name == 'nt' else 'clear')

    def render_board(self, board_data: list[list[int]]):
        """
        Renderuje planszę gry w konsoli.
        """
        board_size = len(board_data)
        self.clear_screen()
        
        # Górna ramka
        self.render_message(f"\n{UI_COLORS['BOARD_BORDER']}+{'-' * (self.tile_width * board_size + board_size - 1)}+{UI_COLORS['RESET']}")

        for row_idx, row in enumerate(board_data):
            row_str = f"{UI_COLORS['BOARD_BORDER']}|{UI_COLORS['RESET']}"
            for tile in row:
                color_back, color_fore = self._get_tile_color(tile)
                tile_str = str(tile).center(self.tile_width) if tile != 0 else ' '.center(self.tile_width)
                row_str += f"{color_back}{color_fore}{tile_str}{Style.RESET_ALL}{UI_COLORS['BOARD_BORDER']}|{UI_COLORS['RESET']}"
            self.render_message(row_str)
            
            # Linia dzieląca kafelki
            if row_idx < board_size - 1:
                separator_line = f"{UI_COLORS['BOARD_BORDER']}+{'-' * self.tile_width}"
                for _ in range(board_size - 1):
                    separator_line += f"+{'-' * self.tile_width}"
                separator_line += f"+{UI_COLORS['RESET']}"
                self.render_message(separator_line)

        # Dolna ramka
        self.render_message(f"{UI_COLORS['BOARD_BORDER']}+{'-' * (self.tile_width * board_size + board_size - 1)}+{UI_COLORS['RESET']}")


    def _get_tile_color(self, tile_value: int):
        """
        Zwraca kolory tła i tekstu dla danego kafelka.
        """
        return TILE_COLORS.get(tile_value, (Back.BLACK, Fore.WHITE))

    def render_message(self, message: str):
        """
        Wyświetla komunikat w konsoli.
        """
        print(message)

    def render_header(self, text: str):
        """
        Wyświetla sformatowany nagłówek.
        """
        self.clear_screen()
        print(f"{UI_COLORS['HEADER']}{text.center(os.get_terminal_size().columns)}{UI_COLORS['RESET']}\n")

    def render_menu_option(self, option_text: str, is_selected: bool = False):
        """
        Wyświetla opcję menu, z opcjonalnym wyróżnieniem.
        """
        if is_selected:
            print(f"{UI_COLORS['MENU_SELECTED']}{option_text.ljust(os.get_terminal_size().columns)}{UI_COLORS['RESET']}")
        else:
            print(f"{UI_COLORS['MENU_OPTION']}{option_text}{UI_COLORS['RESET']}")