#src/stats/game_stats.py

"""
Moduł do śledzenia statystyk gry, takich jak wynik, liczba ruchów,
najwyższy osiągnięty kafelek i czas gry.
"""

import time
from src.utils.logger import game_logger

class GameStats:
    """
    Klasa przechowująca i zarządzająca statystykami bieżącej gry.
    """
    def __init__(self):
        self.logger = game_logger
        self.reset_stats()

    def reset_stats(self):
        """
        Resetuje wszystkie statystyki gry.
        """
        self._score = 0
        self._moves = 0
        self._max_tile = 0
        self._start_time = time.time()
        self._end_time = None
        self.logger.debug("Statystyki gry zresetowane.")

    def add_score(self, points: int):
        """
        Dodaje punkty do bieżącego wyniku.
        """
        self._score += points
        self.logger.debug(f"Dodano {points} punktów. Aktualny wynik: {self._score}")

    def get_score(self) -> int:
        """
        Zwraca bieżący wynik gry.
        """
        return self._score

    def set_score(self, score: int):
        """
        Ustawia bieżący wynik (np. podczas wczytywania gry).
        """
        self._score = score
        self.logger.debug(f"Wynik ustawiony na: {self._score}")

    def increment_moves(self):
        """
        Zwiększa licznik ruchów.
        """
        self._moves += 1
        self.logger.debug(f"Liczba ruchów: {self._moves}")

    def decrement_moves(self):
        """
        Zmniejsza licznik ruchów (dla funkcji undo).
        """
        if self._moves > 0:
            self._moves -= 1
            self.logger.debug(f"Liczba ruchów zmniejszona do: {self._moves}")

    def get_moves(self) -> int:
        """
        Zwraca liczbę wykonanych ruchów.
        """
        return self._moves

    def set_moves(self, moves: int):
        """
        Ustawia liczbę wykonanych ruchów
        """
        self._moves = moves
        self.logger.debug(f"Liczba ruchów ustawiona na: {self._moves}")

    def update_max_tile(self, tile_value: int):
        """
        Aktualizuje wartość najwyższego kafelka.
        """
        if tile_value > self._max_tile:
            self._max_tile = tile_value
            self.logger.debug(f"Najwyższy kafelek zaktualizowany do: {self._max_tile}")

    def get_max_tile(self) -> int:
        """
        Zwraca wartość najwyższego osiągniętego kafelka.
        """
        return self._max_tile

    def get_time_elapsed(self) -> float:
        """
        Zwraca czas, który upłynął od rozpoczęcia gry.
        """
        if self._end_time:
            return self._end_time - self._start_time
        return time.time() - self._start_time

    def end_timer(self):
        """
        Zatrzymuje licznik czasu gry.
        """
        self._end_time = time.time()
        self.logger.debug("Zegar gry zatrzymany.")