#src/stats/analytics.py

"""
Moduł odpowiedzialny za generowanie i wizualizację statystyk gry.
"""

import matplotlib.pyplot as plt
import pandas as pd
import os
import datetime
from src.core.constants import REPORTS_DIR, UI_COLORS
from src.utils.logger import game_logger

class AnalyticsManager:
    """
    Klasa zarządzająca generowaniem raportów i wizualizacją statystyk gry.
    """
    def __init__(self, highscore_manager, config_manager, logger)
        self.highscore_manager = highscore_manager
        self.config_manager = config_manager
        self.logger = logger
        self._ensure_reports_dir_exists()

    def _ensure_reports_dir_exists(self):
        """
        Upewnia się, że katalog na raporty istnieje.
        """
        if not os.path.exists(REPORTS_DIR):
            os.makedirs(REPORTS_DIR)
            self.logger.info(f"Utworzono katalog raportów: {REPORTS_DIR}")

    def generate_stats_report(self):
        """
        Generuje raport statystyk gry, np. histogram wyników.
        """
        self.logger.info("Generowanie raportu statystyk...")
        all_scores = self.highscore_manager.get_all_highscores()
        
        if not all_scores:
            self.logger.warning("Brak danych o wynikach do wygenerowania raportu.")
            return

        scores = [entry['score'] for entry in all_scores]
        dates = [entry['date'] for entry in all_scores]

        df = pd.DataFrame({'score': scores, 'date': dates})

        # Histogram wyników
        plt.figure(figsize=(10, 6))
        plt.hist(df['score'], bins=10, edgecolor='black')
        plt.title('Rozkład wyników w grze 2048')
        plt.xlabel('Wynik')
        plt.ylabel('Częstotliwość')
        plt.grid(axis='y', alpha=0.75)
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        histogram_path = os.path.join(REPORTS_DIR, f"scores_histogram_{timestamp}.png")
        plt.savefig(histogram_path)
        self.logger.info(f"Histogram wyników zapisany do: {histogram_path}")
        plt.close()

        self.logger.info("Generowanie raportu statystyk zakończone.")