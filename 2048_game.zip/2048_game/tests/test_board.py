#tests/test_board.py

"""
Testy jednostkowe dla modułu src/core/board.py.
"""

import unittest
from src.core.board import Board
from src.utils.exceptions import InvalidMoveException, GameLogicError

class TestBoard(unittest.TestCase):
    """
    Zestaw testów dla klasy Board, sprawdzający podstawowe funkcjonalności planszy gry 2048.
    """

    def setUp(self):
        """
        Metoda wywoływana przed każdym testem.
        Tworzy nową planszę 4x4 dla każdego testu.
        """
        self.board = Board(4)
        self.board.board = [[0, 0, 0, 0],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0]]
        self.board._score = 0
        self.board._moves = 0
        self.board._won = False
        self.board._game_over = False

    def test_board_initialization(self):
        """
        Testuje prawidłową inicjalizację planszy.
        """
        test_board = Board(4)
        self.assertEqual(test_board.size, 4)
        self.assertEqual(test_board.board, [[0]*4 for _ in range(4)])
        self.assertEqual(test_board._score, 0)
        self.assertEqual(test_board._moves, 0)
        self.assertFalse(test_board._won)
        self.assertFalse(test_board._game_over)

        # Test nieprawidłowego rozmiaru
        with self.assertRaises(ValueError):
            Board(2)
        with self.assertRaises(ValueError):
            Board(7)

    def test_initialize_board(self):
        """
        Testuje inicjalizację planszy z losowymi kafelkami.
        Sprawdza, czy dodano oczekiwaną liczbę kafelków (2)
        i czy wynik/ruchy zostały zresetowane.
        """
        self.board.initialize_board()
        # Sprawdza, czy na planszy są dokładnie 2 kafelki różne od zera
        tile_count = sum(1 for row in self.board.board for tile in row if tile != 0)
        self.assertEqual(tile_count, 2)
        self.assertEqual(self.board.get_score(), 0)
        self.assertEqual(self.board.get_moves(), 0)
        self.assertFalse(self.board.has_won())
        self.assertFalse(self.board.is_game_over())

    def test_add_random_tile(self):
        """
        Testuje dodawanie losowego kafelka.
        """
        empty_cells_before = len(self.board.get_empty_cells())
        self.board.add_random_tile()
        empty_cells_after = len(self.board.get_empty_cells())
        self.assertEqual(empty_cells_before - 1, empty_cells_after)
        
        # Sprawdza, czy dodany kafelek to 2 lub 4
        added_tile_value = None
        for r in range(self.board.size):
            for c in range(self.board.size):
                if self.board.board[r][c] != 0:
                    added_tile_value = self.board.board[r][c]
                    break
            if added_tile_value:
                break
        self.assertIn(added_tile_value, [2, 4])

    def test_get_empty_cells(self):
        """
        Testuje zwracanie listy pustych komórek.
        """
        self.assertEqual(len(self.board.get_empty_cells()), 16)
        self.board.board[0][0] = 2
        self.assertEqual(len(self.board.get_empty_cells()), 15)
        self.board.board[3][3] = 4
        self.assertEqual(len(self.board.get_empty_cells()), 14)

    def test_make_move_up(self):
        """
        Testuje ruch w górę.
        """
        self.board.board = [[0, 2, 0, 0],
                            [0, 2, 0, 0],
                            [0, 4, 0, 0],
                            [0, 4, 0, 0]]
        initial_score = self.board.get_score()
        initial_moves = self.board.get_moves()

        _, merged_positions = self.board.make_move('UP', 2048)
        
        expected_board = [[0, 4, 0, 0],
                          [0, 8, 0, 0],
                          [0, 0, 0, 0],
                          [0, 0, 0, 0]]
        
        # Test, czy kafelki są na swoich miejscach w kolumnie 1
        self.assertEqual(self.board.board[0][1], 4)
        self.assertEqual(self.board.board[1][1], 8)
        self.assertEqual(self.board.board[2][1], 0)
        self.assertEqual(self.board.board[3][1], 0)

        self.assertEqual(self.board.get_score(), initial_score + 4 + 8)
        self.assertEqual(self.board.get_moves(), initial_moves + 1)
        self.assertIn((0,1), merged_positions)
        self.assertIn((1,1), merged_positions)


    def test_make_move_left(self):
        """
        Testuje ruch w lewo.
        """
        self.board.board = [[2, 2, 0, 0],
                            [4, 4, 0, 0],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0]]
        initial_score = self.board.get_score()

        _, merged_positions = self.board.make_move('LEFT', 2048)
        
        self.assertEqual(self.board.board[0][0], 4)
        self.assertEqual(self.board.board[1][0], 8)
        self.assertEqual(self.board.get_score(), initial_score + 4 + 8)
        self.assertIn((0,0), merged_positions)
        self.assertIn((1,0), merged_positions)


    def test_make_move_right(self):
        """
        Testuje ruch w prawo.
        """
        self.board.board = [[0, 0, 2, 2],
                            [0, 0, 4, 4],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0]]
        initial_score = self.board.get_score()

        _, merged_positions = self.board.make_move('RIGHT', 2048)
        
        self.assertEqual(self.board.board[0][3], 4)
        self.assertEqual(self.board.board[1][3], 8)
        self.assertEqual(self.board.get_score(), initial_score + 4 + 8)
        self.assertIn((0,3), merged_positions)
        self.assertIn((1,3), merged_positions)


    def test_make_move_down(self):
        """
        Testuje ruch w dół.
        """
        self.board.board = [[0, 0, 0, 0],
                            [0, 2, 0, 0],
                            [0, 2, 0, 0],
                            [0, 4, 0, 0]]
        initial_score = self.board.get_score()

        _, merged_positions = self.board.make_move('DOWN', 2048)
        
        self.assertEqual(self.board.board[3][1], 4)
        self.assertEqual(self.board.board[2][1], 4)
        self.assertEqual(self.board.get_score(), initial_score + 4)
        self.assertIn((3,1), merged_positions)


    def test_no_move_exception(self):
        """
        Testuje, czy rzucany jest InvalidMoveException, gdy ruch nie zmienia planszy.
        """
        self.board.board = [[2, 4, 8, 16],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0],
                            [0, 0, 0, 0]]
        with self.assertRaises(InvalidMoveException):
            self.board.make_move('LEFT', 2048)

    def test_has_won(self):
        """
        Testuje warunek wygranej.
        """
        self.board.target_value = 16
        self.board.board[0][0] = 16
        self.assertTrue(self.board.has_won())
        self.assertTrue(self.board._won)

        # Upewnia się, że nie wygrywa, jeśli wartość docelowa nie została osiągnięta
        self.setUp()
        self.board.target_value = 32
        self.board.board[0][0] = 16
        self.assertFalse(self.board.has_won())

    def test_is_game_over_empty_cells(self):
        """
        Testuje, czy gra jest zakończona, gdy nie ma pustych komórek i możliwych ruchów.
        """
        # Plansza pełna, bez możliwości połączeń
        self.board.board = [[2, 4, 8, 16],
                            [32, 64, 128, 256],
                            [512, 1024, 2048, 4],
                            [8, 16, 32, 64]]
        self.assertTrue(self.board.is_game_over())
        self.assertTrue(self.board._game_over)

        # Plansza pełna, ale z możliwością ruchu (np. łączenia)
        self.setUp()
        self.board.board = [[2, 2, 4, 8],
                            [16, 32, 64, 128],
                            [256, 512, 1024, 2048],
                            [2, 4, 8, 16]]
        self.assertFalse(self.board.is_game_over())

    def test_is_game_over_won(self):
        """
        Testuje, czy gra jest zakończona po wygranej.
        """
        self.board.target_value = 4
        self.board.board[0][0] = 4
        self.board.has_won()
        self.assertTrue(self.board.is_game_over())

    def test_can_make_any_move(self):
        """
        Testuje, czy funkcja prawidłowo wykrywa możliwe ruchy.
        """
        # Brak możliwości ruchu
        self.board.board = [[2, 4, 8, 16],
                            [32, 64, 128, 256],
                            [512, 1024, 2048, 4],
                            [8, 16, 32, 64]]
        self.assertFalse(self.board.can_make_any_move())

        # Ruch możliwy (np. w lewo)
        self.board.board = [[2, 2, 4, 8],
                            [16, 32, 64, 128],
                            [256, 512, 1024, 2048],
                            [2, 4, 8, 16]]
        self.assertTrue(self.board.can_make_any_move())

        # Tylko puste pola
        self.setUp()
        self.assertFalse(self.board.can_make_any_move())

    def test_set_board_state(self):
        """
        Testuje ustawianie stanu planszy.
        """
        new_state = [[2, 0, 0, 0],
                     [4, 0, 0, 0],
                     [8, 0, 0, 0],
                     [16, 0, 0, 0]]
        new_score = 100
        new_moves = 5
        new_won = True
        new_game_over = False

        self.board.set_board_state(new_state, new_score, new_moves, new_won, new_game_over)
        self.assertEqual(self.board.get_board(), new_state)
        self.assertEqual(self.board.get_score(), new_score)
        self.assertEqual(self.board.get_moves(), new_moves)
        self.assertTrue(self.board.has_won())
        self.assertFalse(self.board.is_game_over())

        # Test z nieprawidłowymi danymi
        with self.assertRaises(GameLogicError):
            self.board.set_board_state([[1,2],[3]], 0, 0, False, False)
        with self.assertRaises(GameLogicError):
            self.board.set_board_state([[1,2,3,4],[5,6,7,8]], 0, 0, False, False)


    def test_get_score(self):
        """
        Testuje pobieranie wyniku.
        """
        self.board._score = 500
        self.assertEqual(self.board.get_score(), 500)

    def test_get_moves(self):
        """
        Testuje pobieranie liczby ruchów.
        """
        self.board._moves = 10
        self.assertEqual(self.board.get_moves(), 10)

if __name__ == '__main__':
    unittest.main()