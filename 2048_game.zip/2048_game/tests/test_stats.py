
import unittest
from src.core.game import GameStats
import time

class TestGameStats(unittest.TestCase):
    def test_move_tracking(self):
        stats = GameStats()
        stats.move_count += 1
        stats.update_max_tile(128)
        stats.update_max_tile(64)
        self.assertEqual(stats.move_count, 1)
        self.assertEqual(stats.max_tile, 128)

    def test_timer(self):
        stats = GameStats()
        time.sleep(0.5)
        self.assertGreater(stats.get_elapsed_time(), 0.4)
